from cryptography.fernet import Fernet


file = open ('key.key', 'rb')
file.read(key)
print (key)
