from cryptography.fernet import Fernet

file = open ('key.key', 'rb')
key = file.read()
file.close()

with open('jcssdunit4.txt.encrypted', 'rb') as f:
    data = f.read()

fernet = Fernet(key)
encrypted = fernet.decrypt(data)

with open('jcssdunit4.txt.decrypted', 'wb') as f:
    f.write(encrypted)
